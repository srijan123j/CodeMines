from django.apps import AppConfig


class ContestsConfig(AppConfig):
    name = 'contests'
