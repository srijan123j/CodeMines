from django.conf.urls import url, include
from django.views.generic import ListView, DetailView
from blogs.models import discussion_forums



urlpatterns = [ url(r'^$', ListView.as_view(queryset=discussion_forums.objects.all().order_by("-date")[:25],
template_name="blogs/blogs.html")),
url(r'^(?P<pk>\d+)$', DetailView.as_view(model = discussion_forums, 
template_name = 'blogs/blogs_detail.html'))]