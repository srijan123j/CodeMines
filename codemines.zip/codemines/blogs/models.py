from django.db import models

class discussion_forums(models.Model):
    title = models.CharField(max_length=250)
    content = models.TextField()
    short_content = models.TextField(null = True)
    author = models.CharField(max_length=150)
    date = models.DateTimeField()