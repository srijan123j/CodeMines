from django.contrib import admin
from blogs.models import discussion_forums

admin.site.register(discussion_forums)