from django.urls import path
from . import views

urlpatterns = [
    path('', views.fac, name='fac'),
]