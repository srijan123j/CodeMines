from django.shortcuts import render
# Create your views here.

def fac(request):
	return render(request, 'faculty/faculty.html')