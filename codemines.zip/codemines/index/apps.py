from django.apps import AppConfig


class IndexConfig(AppConfig):
    name = 'index'
