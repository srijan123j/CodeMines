from django.apps import AppConfig


class CodeismConfig(AppConfig):
    name = 'codeism'
