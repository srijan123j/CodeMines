from django.db import models

# Create your models here.

class problem_statement(models.Model):
	title = models.CharField(max_length=150)
	body = models.TextField()
	level = models.CharField(max_length=20)
	tag = models.CharField(max_length=20)
	likes = models.CharField(null=True,max_length=20)
	dislikes = models.CharField(null=True,max_length=20)
	accuracy = models.CharField(null=True,max_length=20)
	solved = models.CharField(null=True,max_length=20)
	inpute = models.TextField(null=True)
	output = models.TextField(null=True)
	date = models.DateTimeField()
	
	def __str__(self):
		return self.title