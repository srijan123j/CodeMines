from django.contrib import admin
from problems.models import problem_statement

admin.site.register(problem_statement)