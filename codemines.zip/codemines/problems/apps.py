from django.apps import AppConfig


class ProblemsConfig(AppConfig):
    name = 'problems'
